//
//  DatabaseModel.swift
//  My Notes
//
/***
Copyright 2017 Jonathan A Daley

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
***/

import Foundation
import RealmSwift

let appGroupID = "group.edu.JonathanADaley.MyNotes"

/// The `Realm` `Object` class that backs the application's data storage solution.
class Note: Object {
    
    /// The primary key for this `Note`
    @objc dynamic var id = NSUUID().uuidString
    
    /// The title for the note
    @objc dynamic var title = "New Note Title"
    
    /// The `Date` this `Note` was last modified
    @objc dynamic var date = Date()
    
    /// The text of the note
    @objc dynamic var text = "Type your note text here..."
    
    override static func primaryKey() -> String? {
        return "id"
    }
    
    override static func indexedProperties() -> [String] {
        return ["id","title","date"]
    }
}


/// Model class containing static functions to interact with the Realm database
class MyNotesModel {
    
    private static func GetRealm() throws -> Realm  {
        var config = Realm.Configuration()
        config.fileURL = FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: appGroupID)!
            .appendingPathComponent("default.realm")
        
        return try Realm(configuration: config)
    }
    
    
    /// Creates a Note in the Realm database
    static func CreateBlankNote() {
        do {
            let realm  = try GetRealm()
            try realm.write {
                realm.create(Note.self)
            }
        } catch let error as NSError {
                print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
    }
    
    /// Creates a new note in the Realm database. Can `throw` an error.
    ///
    /// - Parameter content: The note's contents
    /// - Parameter title: The title of the note
    /// - Parameter ID: the unique ID for the note (this MUST be unique to this note instance)
    /// - Parameter date: the `Date` the note was created on
    static func CreateNewNote(withContent content:String, andTitle title:String, andID ID:String, onDate date:Date) throws {
        do {
            let realm = try GetRealm()
            
            let note = Note()
            note.text = content
            note.title = title
            note.id = ID
            note.date = date
            
            try realm.write {
                realm.add(note)
            }
            
        } catch let error as NSError {
            print("Error. Error Domain: \(error.domain) Error Description: \(error.description)")
            throw error
        }
    }
    
    /// Gets all notes, sorted by date (ascending)
    ///
    /// - Returns: Returns the `Results<Note>?` in Realm, sorted by date (ascending); or returns `nil` if there is an error
    static func GetAllNotes() -> Results<Note>? {
        
        do {
            let realm  = try GetRealm()
            let notes = realm.objects(Note.self).sorted(byKeyPath: "date", ascending: false)
            return notes
        }
        catch let error as NSError {
            print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
        
        return nil
    }
    
    /// Gets notes whose title begins with the text passed in
    ///
    /// - Parameter text: The string to search fo
    /// - Returns: Returns notes whose title begins with the text passed in
    static func GetNotes(withTitle text:String) -> Results<Note>? {
        
        // text can't be an empty string, or the predicate string won't be able to be parsedle
        guard text != "" else { return nil }
        
        do {
            let realm = try GetRealm()
            let notes = realm.objects(Note.self).filter("title BEGINSWITH '\(text)'")/* OR text CONTAINS '\(text)?'")*/.sorted(byKeyPath: "date", ascending: false)
            print("Found \(notes.count) notes")
            return notes
        } catch let error as NSError {
            print("Error. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
        
        return nil
    }
    
    /// Gets a single note for the passed in id
    ///
    /// - Parameter id: The unique id for the note
    /// - Returns: Returns a `Note` if it is found and there is not error, otherwise returns nil
    static func GetNote(withID id:String) -> Note? {
        guard id != "" else {
            return nil
        }
        
        do {
            let realm  = try GetRealm()
            let noteWithId = realm.objects(Note.self).filter("id = '\(id)'")
            if noteWithId.count != 0 {
                return noteWithId[0]
            } else {
                return nil
            }
            
        }
        catch let error as NSError {
            print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
        return nil;
    }
    
    /// Updates the title and modified date of a `Note`
    ///
    /// - Parameters:
    ///   - note: The `Note` the will be updated.
    ///   - title: The new title `String`
    ///   - date: The new `Date` the `Note` was modified
    static func UpdateNote(_ note:Note, newTitle title:String, newDate date:Date) {
        
        guard !note.isInvalidated else {
            return
        }
        
        do {
            let realm  = try GetRealm()
            try realm.write {
                note.title = title
                note.date = date
            }
        } catch let error as NSError {
            print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
    }
    
    
    /// Updates the text and modified date of a `Note`
    ///
    /// - Parameters:
    ///   - note: The `Note` the will be updated.
    ///   - text: The new text `String`
    ///   - date: The new `Date` the `Note` was modified
    static func UpdateNote(_ note:Note, newText text:String, newDate date:Date) {
        
        guard !note.isInvalidated else {
            return
        }
        
        do {
            let realm  = try GetRealm()
            try realm.write {
                note.text = text
                note.date = date
            }
        } catch let error as NSError {
            print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
    }
    
    
    /// Deletes the note with the passed in ID (primary key)
    ///
    /// - Parameter id: The Primary Key for the note to delete
    /// - Returns: Returns `true` if the deletion was successful, returns `false` if the object could not be found
    static func DeleteNote(with id:String) -> Bool {
        do {
            let realm  = try GetRealm()
            
            guard let noteToDelete = realm.object(ofType: Note.self, forPrimaryKey: id) else {
                return false
            }
            
            try realm.write {
                realm.delete(noteToDelete)
            }
            
            return true
        }
        catch let error as NSError {
            print("Error accessing Realm. Error Domain: \(error.domain) Error Description: \(error.description)")
        }
        
        return false
    }
}
