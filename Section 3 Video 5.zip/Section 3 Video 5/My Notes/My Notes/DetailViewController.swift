//
//  DetailViewController.swift
//  My Notes
//
/***
Copyright 2017 Jonathan A Daley

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
***/

import UIKit
import RealmSwift

class DetailViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var NoteTitleTextField: UITextField!
    @IBOutlet weak var NoteBodyTextView: UITextView!
    @IBOutlet weak var NoteDateLabel: UILabel!
    
    var displayedNoteID: String = ""
    var reloadMasterTableView:(() -> Void)?
    
    private var note:Note? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        NoteTitleTextField.delegate = self
        NoteBodyTextView.delegate = self
        note = MyNotesModel.GetNote(withID: displayedNoteID)
        if note == nil {
            if let notes = MyNotesModel.GetAllNotes() {
                note = notes[0]
            }
        }
        updateTextDisplay()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        NoteBodyTextView.becomeFirstResponder()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func clearEnteredText() {
        NoteBodyTextView.text = ""
        NoteTitleTextField.text = ""
        NoteDateLabel.text = ""
    }
    
    private func updateTextDisplay() {
        guard let noteToDisplay = note else {
            return
        }
        
        NoteTitleTextField.text = noteToDisplay.title
        NoteBodyTextView.text = noteToDisplay.text
        NoteDateLabel.text = "Edited: \(noteToDisplay.date)"
    }
    
    
    
    // MARK: - TextView delegate methods
    func textViewDidChange(_ textView: UITextView) {
        guard let noteToDisplay = note else {
            return
        }
        MyNotesModel.UpdateNote(noteToDisplay, newText: textView.text, newDate: Date())
        NoteDateLabel.text = "Edited: \(noteToDisplay.date)"
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if reloadMasterTableView != nil {
            reloadMasterTableView!()
        }
    }
    
    // MARK: - TextField delegate methods
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
        guard let noteToDisplay = note else {
            return
        }
        
        if let textFieldText = textField.text {
            MyNotesModel.UpdateNote(noteToDisplay, newTitle: textFieldText, newDate: Date())
            NoteDateLabel.text = "Edited: \(noteToDisplay.date)"
            if reloadMasterTableView != nil {
                reloadMasterTableView!()
            }
        } else {
            textField.text = noteToDisplay.title
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.selectAll(nil)
    }

}

