//
//  CreateNoteIntentHandler.swift
//  MyNotesIntentExt
//
/***
Copyright 2017 Jonathan A Daley

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
***/

import Foundation
import Intents

class CreateNoteIntentHandler: NSObject, INCreateNoteIntentHandling {
    
    private let noteDate = Date()
    private let noteUUID = NSUUID().uuidString
    
    func resolveTitle(for intent: INCreateNoteIntent, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
        guard let title = intent.title  else {
            completion(INSpeakableStringResolutionResult.confirmationRequired(with: INSpeakableString(spokenPhrase: "New Note Title")))
            return
        }
        
        guard title.spokenPhrase != "" else {
            completion(INSpeakableStringResolutionResult.confirmationRequired(with: INSpeakableString(spokenPhrase: "New Note Title")))
            return
        }
        
        completion(INSpeakableStringResolutionResult.success(with: INSpeakableString(spokenPhrase: title.spokenPhrase)))
    }
    
    func resolveContent(for intent: INCreateNoteIntent, with completion: @escaping (INNoteContentResolutionResult) -> Void) {
        guard let content = intent.content else {
            completion(INNoteContentResolutionResult.confirmationRequired(with: INTextNoteContent(text: "New Note Text")))
            return
        }
        
        guard content is INTextNoteContent else {
            completion(INNoteContentResolutionResult.confirmationRequired(with: INTextNoteContent(text: "New Note Text")))
            return
        }
        
        let textContent = content as! INTextNoteContent
        
        guard textContent.text != nil else {
            completion(INNoteContentResolutionResult.confirmationRequired(with: INTextNoteContent(text: "New Note Text")))
            return
        }
        
        completion(INNoteContentResolutionResult.success(with: content))
    }
    
    func confirm(intent: INCreateNoteIntent, completion: @escaping (INCreateNoteIntentResponse) -> Void) {
        
        guard let content = intent.content else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        guard let title = intent.title else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        guard content is INTextNoteContent else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        let noteContent = content as! INTextNoteContent
        
        guard noteContent.text != nil else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        let response = INCreateNoteIntentResponse(code: .ready, userActivity: nil)
        
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone.current
        let components = calendar.dateComponents(in: calendar.timeZone, from: noteDate)
        
        response.createdNote = INNote(title: INSpeakableString(spokenPhrase: title.spokenPhrase), contents: [content], groupName: nil, createdDateComponents: components, modifiedDateComponents: components, identifier: noteUUID)
        
        completion(response)
        
    }
    
    func handle(intent: INCreateNoteIntent, completion: @escaping (INCreateNoteIntentResponse) -> Void) {
        
        guard let content = intent.content else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        guard let title = intent.title else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        guard content is INTextNoteContent else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        let noteContent = content as! INTextNoteContent
        
        guard let noteText = noteContent.text else {
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        do {
            try MyNotesModel.CreateNewNote(withContent: noteText, andTitle: title.spokenPhrase, andID: noteUUID, onDate: noteDate)
        } catch let error as NSError {
            print("Error. Error Domain: \(error.domain) Error Description: \(error.description)")
            
            completion(INCreateNoteIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        let response = INCreateNoteIntentResponse(code: .success, userActivity: nil)
        
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone.current
        let components = calendar.dateComponents(in: calendar.timeZone, from: noteDate)
        
        response.createdNote = INNote(title: INSpeakableString(spokenPhrase: title.spokenPhrase), contents: [content], groupName: nil, createdDateComponents: components, modifiedDateComponents: components, identifier: noteUUID)
        
        completion(response)

    }
    
    
}






